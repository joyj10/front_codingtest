const bodyParser = require('body-parser');

module.exports = bodyParser.urlencoded({ extended: true });
